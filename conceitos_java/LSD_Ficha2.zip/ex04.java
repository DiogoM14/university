public class ex04 {
  public static void main(String[] args) {
    for(int i = 0; i <= 300; i=i+2) {
      System.out.println(i);
    }
  }
}
