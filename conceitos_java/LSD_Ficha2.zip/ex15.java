import java.util.Random;
import java.util.Scanner;

public class ex15 {
  public static void main(String[] args) {
    int num;

    num = 0;

    Scanner scanner = new Scanner(System.in);
    Random gerador = new Random();

    System.out.print();

    gerador.nextInt(100);
    if()
  }
}
